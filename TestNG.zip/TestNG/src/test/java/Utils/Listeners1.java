package Utils;

import java.io.File; 
import java.io.IOException;
import java.net.URI;
import java.nio.file.FileSystem;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.nio.file.WatchEvent.Kind;
import java.nio.file.WatchEvent.Modifier;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.microsoft.playwright.Page;

import Base.Page1;

public class Listeners1 extends Page1 implements ITestListener  {

	
	
	public Listeners1() throws IOException {
		super();
	}

	private static String getTestMethodName(ITestResult result) {
		return result.getMethod().getConstructorOrMethod().getName();

	}
	
	@Override
	public void onTestStart(ITestResult result) {
		
		System.out.println("Test is started with " + getTestMethodName(result));
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println( getTestMethodName(result)+ " method is pass");
	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println("Failed test method is " + getTestMethodName(result)+ " Because i add Assertion who fail the Login() method for capturing the screenshot");
		saveFailureScreenshot(page);
		
	}
	
	public void  saveFailureScreenshot(Page page) { 
		Path path = Paths.get("Screenshot\\Screenshot.png");
		page.screenshot(new Page.ScreenshotOptions().setPath(path));
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
		ITestListener.super.onTestSkipped(result);
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		ITestListener.super.onTestFailedButWithinSuccessPercentage(result);
	}

	@Override
	public void onTestFailedWithTimeout(ITestResult result) {
		// TODO Auto-generated method stub
		ITestListener.super.onTestFailedWithTimeout(result);
	}

	@Override
	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
		ITestListener.super.onStart(context);
	}

	@Override
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		ITestListener.super.onFinish(context);
	}

	
	
}
