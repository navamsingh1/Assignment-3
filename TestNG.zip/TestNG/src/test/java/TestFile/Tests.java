package TestFile;

import java.io.IOException;
import java.util.Properties;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;
import com.microsoft.playwright.Page;
import Base.Page1;
import Pages.Pages;
import Utils.Listeners1;
@Listeners(Listeners1.class)
public class Tests extends Page1{
public static Pages Page;
public static String Username;
public static String Password;
public static String CardName;
public static String CardValue;
public static String CVC;
public static String ExpireMonth;
public static String ExpireYear;

	public Tests() throws IOException {
		 Page=new Pages(pr,page);
		 
	}
	
	//Fetch values from properties file
	@BeforeTest
	public void GetValues() {
		Username= pr.getProperty("Username");
		Password= pr.getProperty("Password");		
		CardName= pr.getProperty("CardName");
		CardValue= pr.getProperty("CardValue");
		CVC= pr.getProperty("CVC");
		ExpireMonth= pr.getProperty("ExpireMonth");
		ExpireYear= pr.getProperty("ExpireYear");
	
	}
	// Assert that logo is visible and Assert that logout button is visible after login
    @Test(priority=1)
	public void Login() {
    assertThat(page.locator("//img[@alt='Website for automation practice']")).isVisible();   
	Page.SignupLogin();
	Page.login(Username, Password); 
	assertThat(page.locator("a[href='/logout']")).isVisible(); 
	
	// I add this Assert.assertTrue(false); because this will capture the screenshot when condition is fail there will be no impact on testcase. 
	Assert.assertTrue(false);
	 
	}

    // Add first product
    @Test(priority=2)
    public void FirstProduct() {
    	Page.AddFirstProduct();
    	Page.Continue();
    }
    // Add second product and Assert that both product is added
    @Test(priority=3)
    public void SecondProduct() {
    	Page.AddSecondProduct();
    	Page.ViewCart();
    	assertThat(page.locator("//a[text()='Blue Top']")).isVisible();
    	assertThat(page.locator("//a[text()='Men Tshirt']")).isVisible();
    }
    // Proceed and make payment and assert that order is placed
    @Test(priority=4)
    public void Proceed() {
    	Page.CheckOut();
    	Page.ScrollDown();
    	Page.PlaceOrder();
    	Page.EnterCardDetails(CardName, CardValue, CVC, ExpireMonth, ExpireYear);
    	assertThat(page.locator("//b[text()='Order Placed!']")).isVisible();
    }  
    
}
