package Base;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite; 
import com.microsoft.playwright.Browser; 
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

import Pages.Pages;

public class Page1 {
	
	public static Properties pr = new Properties();
	public static Page page;
	public static Playwright playwright;
	public static BrowserContext context;
	// Constructor will call and file will load
	public Page1() throws IOException {
	FileReader file =new FileReader(System.getProperty("user.dir")+"\\src\\main\\resources\\TestData.properties");
	pr.load(file);

	}
	// this will run first
	@BeforeSuite
	public void Setup() {
		 playwright = Playwright.create();{
			Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions()
					.setHeadless(false));
			BrowserContext context = browser.newContext();
			page = context.newPage();
			page.navigate("https://www.automationexercise.com/");	
			Pages Page=new Pages(pr,page);
		}
	}
	// This will run last
	@AfterSuite
	public void TearDown() {
		playwright.close();
		context.close();
		page.close();
	}
}